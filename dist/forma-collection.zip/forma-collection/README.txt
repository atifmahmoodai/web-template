FORMA — A better starting point

Six responsive website templates. No dependencies or build step.

Studio — creative agency (studio.html)
Folio — creative portfolio (folio.html)
Signal — software product (signal.html)
Sunday — design objects storefront (sunday.html)
Chapter — editorial journal (chapter.html)
Gather — creative event (gather.html)

GET STARTED
1. Open any HTML file in your browser.
2. Open the same file in a code editor to change text and styles.
3. Replace example details, email addresses, dates, prices, and images.
4. Test your edits on desktop and mobile.
5. Rename your finished file index.html and upload it to static hosting.

Everything needed for each design is embedded in the HTML file, including original SVG artwork. You may add your own external files.

Sunday's bag, Chapter's signup, Gather's attendance inquiry, and Signal's billing controls are front-end demonstrations. They do not process payments, send messages, create accounts, or register attendees. Connect real services for your project.

LICENSE
MIT. Personal and commercial use are permitted. Keep the license notice in source files. See LICENSE.txt.
